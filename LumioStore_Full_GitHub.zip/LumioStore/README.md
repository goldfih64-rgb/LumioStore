# Lumio Store

Повний Android-проєкт Lumio Store.

## Як отримати APK через GitHub
1. Завантаж всі файли цього проєкту у репозиторій `LumioStore`.
2. Відкрий вкладку **Actions**.
3. Обери **Build Lumio Store APK**.
4. Відкрий останній успішний запуск.
5. Внизу в **Artifacts** натисни **LumioStore-APK**.
6. Розпакуй ZIP і встанови `app-debug.apk`.

GitHub автоматично збирає APK після кожного push у `main`.

Package: `com.lumio.store`
