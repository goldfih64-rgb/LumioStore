# Lumio Store White v2

Нова Android-версія Lumio Store у світлому стилі.

Додано:
- світлий дизайн;
- нове нижнє меню без gamepad-стікера;
- пошук за програмою / студією / категорією;
- Login / Register;
- локальний Admin login;
- публікація програми для звичайного користувача — $5;
- для Admin публікація безкоштовна;
- верифікація людини — $5;
- верифікація компанії — $5;
- Admin може видати верифікацію безкоштовно;
- платні й безкоштовні застосунки;
- Admin може змінювати ціну;
- завантаження іконки;
- APK/file поле;
- verified badge з `verified.png`.

## Admin demo
Username: `lumio_admin`
Password: `2468`

Це ЛИШЕ локальний demo-admin. У публічному репозиторії пароль видно в коді.
Для реального магазину авторизацію треба перенести на сервер/backend.

## Google Play payments
У цій версії є готовий UI і логіка тарифів.
Реальні списання через Google Play НЕ можуть працювати лише з HTML.
Потрібні Google Play Console, Billing Library та серверна перевірка платежів.

## APK distribution
Локально вибраний APK доступний тільки на тому самому пристрої.
Щоб інші користувачі реально завантажували APK, додай прямий HTTPS URL до APK
(GitHub Release, сервер, object storage тощо).

GitHub Actions у `.github/workflows/build-apk.yml` збирає Android APK.
